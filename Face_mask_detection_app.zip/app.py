import streamlit as st
import cv2
from ultralytics import YOLO
import tempfile
import time

# Load YOLO model
model = YOLO("best.pt")

st.title("🎥 Real-Time Face Mask Detection")
st.markdown("Keep your webcam on, and detection will start automatically.")

# OpenCV Video Capture
cap = cv2.VideoCapture(0)

if not cap.isOpened():
    st.error("❌ Failed to access webcam.")
else:
    stframe = st.empty()  # placeholder for video frames
    while True:
        ret, frame = cap.read()
        if not ret:
            st.error("⚠️ Failed to grab frame.")
            break

        # Run YOLO prediction
        results = model.predict(frame, conf=0.5, verbose=False)

        # Plot detections on frame
        annotated_frame = results[0].plot()

        # Show in Streamlit
        stframe.image(annotated_frame, channels="BGR", use_container_width=True)

        # Delay for smoother video
        time.sleep(0.03)

cap.release()
